% Chapter 11: Interior-point methods
%
%  log_utility_flow.m - Section 11.8.4: Network rate optimization
help Contents
